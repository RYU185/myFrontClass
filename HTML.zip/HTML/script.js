alert("매일매일 1시간씩.");
        if(confirm("확인?")){
            alert("소질이 있네요...");
        }else{
            alert("더 시도해보세요");
        }